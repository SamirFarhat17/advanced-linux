#include <stdio.h>

int main() {	
    printf("Hello EC605 from safarhat!\n");
}
